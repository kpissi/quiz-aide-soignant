import { useEffect, useState } from "react";
import questionsData from "./questions.json";

function formatTime(seconds) {
  const m = String(Math.floor(seconds / 60)).padStart(2, "0");
  const s = String(seconds % 60).padStart(2, "0");
  return `${m}:${s}`;
}

function App() {
  const [name, setName] = useState("");
  const [started, setStarted] = useState(false);

  const [subject, setSubject] = useState(null);

  const [mode, setMode] = useState(null); // "quiz" | "exam"
  const [timeLeft, setTimeLeft] = useState(15 * 60); // 15 min

  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  const [answers, setAnswers] = useState([]);
  const [history, setHistory] = useState([]);

  // Charger historique
  useEffect(() => {
    try {
      const saved = localStorage.getItem("quizHistory");
      if (saved) setHistory(JSON.parse(saved));
    } catch (e) {
      setHistory([]);
    }
  }, []);

  // Chrono examen
  useEffect(() => {
    if (mode !== "exam") return;
    if (finished) return;

    const timer = setInterval(() => {
      setTimeLeft((t) => t - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [mode, finished]);

  // Fin automatique si temps écoulé
  useEffect(() => {
    if (mode !== "exam") return;
    if (timeLeft <= 0 && !finished) {
      setTimeLeft(0);
      finishNow(score);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeLeft, mode]);

  function resetToMenu() {
    setSubject(null);
    setMode(null);
    setTimeLeft(15 * 60);
    setCurrentIndex(0);
    setScore(0);
    setAnswers([]);
    setFinished(false);
  }

  function saveResult(finalScore, total, usedMode) {
    const newResult = {
      name,
      subject,
      mode: usedMode,
      score: finalScore,
      total,
      date: new Date().toLocaleString()
    };
    const updated = [...history, newResult];
    setHistory(updated);
    localStorage.setItem("quizHistory", JSON.stringify(updated));
  }

  function finishNow(finalScore) {
    const questions = questionsData[subject] || [];
    const total = questions.length;
    saveResult(finalScore, total, mode);
    setFinished(true);
  }

  if (!started) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Concours Aide-Soignant 🇨🇮</h2>

        <p>Entre ton nom et prénom :</p>
        <input
          type="text"
          placeholder="Nom / Prénom"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <br />
        <br />

        <button onClick={() => setStarted(true)}>Commencer</button>
      </div>
    );
  }

  // MENU
  if (!subject) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Bienvenue {name} 👋</h2>

        <h3>📊 Mes résultats</h3>
        {history.length === 0 ? (
          <p>Aucun résultat pour le moment</p>
        ) : (
          history.map((h, i) => (
            <p key={i}>
              {h.date} — {h.subject} ({h.mode || "quiz"}) : {h.score}/{h.total}
            </p>
          ))
        )}

        <hr />

        <p>Choisis une matière :</p>
        <ul>
          <li style={{ cursor: "pointer" }} onClick={() => setSubject("SVT")}>
            SVT
          </li>
          <li
            style={{ cursor: "pointer" }}
            onClick={() => setSubject("Français")}
          >
            Français
          </li>
          <li
            style={{ cursor: "pointer" }}
            onClick={() => setSubject("Logique")}
          >
            Logique
          </li>
          <li
            style={{ cursor: "pointer" }}
            onClick={() => setSubject("Culture générale")}
          >
            Culture générale
          </li>
        </ul>
      </div>
    );
  }

  // CHOIX MODE (après matière)
  if (!mode) {
    return (
      <div style={{ padding: 20 }}>
        <h3>{subject}</h3>
        <p>Choisis un mode :</p>

        <button
          onClick={() => {
            setMode("quiz");
            setTimeLeft(15 * 60);
          }}
        >
          Mode révision (sans chrono)
        </button>

        <br />
        <br />

        <button
          onClick={() => {
            setMode("exam");
            setTimeLeft(15 * 60);
          }}
        >
          Mode examen (15 min)
        </button>

        <br />
        <br />

        <button onClick={resetToMenu}>Retour</button>
      </div>
    );
  }

  const questions = questionsData[subject] || [];
  const total = questions.length;
  const question = questions[currentIndex];

  function handleAnswerClick(selectedIndex) {
    const isCorrect = selectedIndex === question.answer;
    const newScore = isCorrect ? score + 1 : score;

    setAnswers([
      ...answers,
      {
        question: question.question,
        selected: selectedIndex,
        correct: question.answer,
        explanation: question.explanation,
        choices: question.choices
      }
    ]);

    setScore(newScore);

    if (currentIndex + 1 < total) {
      setCurrentIndex(currentIndex + 1);
    } else {
      finishNow(newScore);
    }
  }

  if (finished) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Résultat final</h2>
        <p>
          {name}, ton score est : <strong>{score} / {total}</strong>
        </p>

        {mode === "exam" && (
          <p>
            ⏱️ Temps restant : <strong>{formatTime(timeLeft)}</strong>
          </p>
        )}

        <hr />

        {answers.map((a, i) => (
          <div key={i} style={{ marginBottom: 14 }}>
            <p>
              <strong>Q{i + 1} :</strong> {a.question}
            </p>
            <p>✅ Bonne réponse : {a.choices[a.correct]}</p>
            <p>🧠 Explication : {a.explanation}</p>
          </div>
        ))}

        <button onClick={resetToMenu}>Retour au menu</button>
      </div>
    );
  }

  if (!question) {
    return (
      <div style={{ padding: 20 }}>
        <p>Aucune question trouvée pour {subject}.</p>
        <button onClick={resetToMenu}>Retour au menu</button>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <h3>{subject}</h3>
        {mode === "exam" && (
          <div>
            ⏱️ <strong>{formatTime(timeLeft)}</strong>
          </div>
        )}
      </div>

      <p>
        Question {currentIndex + 1} / {total}
      </p>

      <h4>{question.question}</h4>

      <ul>
        {question.choices.map((choice, idx) => (
          <li
            key={idx}
            onClick={() => handleAnswerClick(idx)}
            style={{ cursor: "pointer", marginBottom: 8 }}
          >
            {choice}
          </li>
        ))}
      </ul>

      <button onClick={resetToMenu}>Quitter</button>
    </div>
  );
}

export default App;
